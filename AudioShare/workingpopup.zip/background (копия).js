// background.js
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('Received message:', message);
    if (message.action === 'startCapture') {
        // Захват текущей активной вкладки
        chrome.tabCapture.capture({ audio: true, video: true }, (stream) => {
            if (chrome.runtime.lastError || !stream) {
                console.error('Ошибка при захвате аудио и видео:', chrome.runtime.lastError);
                sendResponse({ status: 'error', error: chrome.runtime.lastError.message });
                return;
            }

            // Запуск записи
            const options = { mimeType: 'video/webm; codecs=vp8,opus' };
            const recorder = new MediaRecorder(stream, options);
            const chunks = [];

            recorder.ondataavailable = (e) => {
                if (e.data.size > 0) {
                    chunks.push(e.data);
                }
            };

            recorder.onstop = () => {
                const blob = new Blob(chunks, { type: 'video/webm' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.style.display = 'none';
                a.href = url;
                a.download = 'recording.webm';
                document.body.appendChild(a);
                a.click();
                URL.revokeObjectURL(url);
                a.remove();
            };

            recorder.start();
            setTimeout(() => recorder.stop(), 1000); // Запись продолжается 5 секунд, можно изменить время

            sendResponse({ status: 'success' });
        });

        // Возвращаем true, чтобы указать, что sendResponse будет вызван асинхронно
        return true;
    }
    if (message.action === 'startCapture2') {
        sendResponse({ status: 'success' });
        return true;
    }

    return true;
});

