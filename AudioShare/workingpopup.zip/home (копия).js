function saveToFile(blob, name) {
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    document.body.appendChild(a);
    a.style = "display: none";
    a.href = url;
    a.download = name;
    a.click();
    URL.revokeObjectURL(url);
    a.remove();
}

function captureTabAudio() {
    chrome.tabCapture.capture({audio: true, video: false}, (stream) => {

        // these lines enable the audio to continue playing while capturing
        context = new AudioContext();
        var newStream = context.createMediaStreamSource(stream);
        newStream.connect(context.destination);

        const recorder = new MediaRecorder(stream);
        const chunks = [];
        recorder.ondataavailable = (e) => {
            chunks.push(e.data);
        };
        recorder.onstop = (e) => saveToFile(new Blob(chunks), "test.wav");
        recorder.start();
        setTimeout(() => recorder.stop(), 5000);
    })
}

function captureTabAudioVideo() {
    chrome.tabCapture.capture({ audio: true, video: true }, (stream) => {
        if (chrome.runtime.lastError || !stream) {
            console.error('Ошибка при захвате аудио и видео:', chrome.runtime.lastError);
            return;
        }

        // Опционально: можно настроить параметры MediaRecorder
        const options = { mimeType: 'video/webm; codecs=vp8,opus' }; // video/webm to capture both audio and video
        const recorder = new MediaRecorder(stream, options);
        const chunks = [];

        // Обработка фрагментов данных, когда они доступны
        recorder.ondataavailable = (e) => {
            if (e.data.size > 0) {
                chunks.push(e.data);
            }
        };

        // Действие после завершения записи
        recorder.onstop = (e) => saveToFile(new Blob(chunks, { type: 'video/webm' }), "recording.webm");

        recorder.start();
        setTimeout(() => recorder.stop(), 5000); // Останавливаем через 5 секунд (пример)
    });
}

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("share-audio-button").addEventListener("click", function (){
        captureTabAudioVideo();
    })
});

chrome.runtime.onInstalled.addListener(() => {
    console.log('Extension ID:', chrome.runtime.id);
});
