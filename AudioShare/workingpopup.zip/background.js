chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('Received message:', message);

    if (message.action === 'startCapture2') {
        console.log('Starting capture process...');
        sendResponse({ status: 'success' });
    } else {
        console.error('Unknown action:', message.action);
        sendResponse({ status: 'error', error: 'Unknown action' });
    }

    // Возвращаем true, чтобы оставить канал открытым для асинхронного ответа
    return true;
});

