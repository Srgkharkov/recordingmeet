// service-worker.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log(sender.tab ? "from a content script:" + sender.tab.url : "from the extension");

    if (request.greeting === "hello from content script" || request.greeting === "hello from button click") {
        console.log("Received message:", request.greeting);
        sendResponse({ farewell: "goodbye" });
        return true; // Добавляем эту строку для асинхронного ответа
    }
});

