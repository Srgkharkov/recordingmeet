// content.js

console.log('Content script loaded');

chrome.runtime.sendMessage({ greeting: "hello from content script" }, (response) => {
    if (response) {
        console.log('Response from background:', response.farewell);
    } else {
        console.error('No response from background script');
        if (chrome.runtime.lastError) {
            console.error('Runtime error:', chrome.runtime.lastError.message);
        }
    }
});


// Добавление кнопки на веб-страницу
const button = document.createElement('button');
button.textContent = 'Send Message to Background';
button.id = "button34232432432";
button.onclick = () => {
    chrome.runtime.sendMessage({ greeting: "hello from button click" }, (response) => {
        if (response) {
            console.log('Response from background:', response.farewell);
        } else {
            console.error('No response from background script');
        }
    });
};
document.body.appendChild(button);

